/**
 * 
 */
package roadgraph;

/**
 * @author dayler
 */
public class Node {
	
	private String name;
	
	
	
}
